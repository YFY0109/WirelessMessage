#include "debug.h"
// 可扩展复杂调试实现，如写入文件、远程输出等
